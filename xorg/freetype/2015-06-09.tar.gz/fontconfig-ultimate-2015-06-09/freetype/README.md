
#### freetype2-infinality-ultimate components

* all patches needed to build `freetype2-infinality-ultimate`
* the recent version of `infinality-settings.sh`

