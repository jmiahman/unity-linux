wget https://github.com/cdave1/freetype2-android/archive/master.tar.gz -O freetype2-android.tar.gz
mkdir -p freetype2-android
tar xvzf freetype2-android.tar.gz -C freetype2-android --strip-components=1
