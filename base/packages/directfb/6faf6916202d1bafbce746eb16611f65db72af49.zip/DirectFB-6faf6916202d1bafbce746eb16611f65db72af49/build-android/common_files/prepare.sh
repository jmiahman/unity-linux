android update project --path . --target android-10
