#ifndef __LOADER_H__
#define __LOADER_H__

#include <fusionsound.h>

IFusionSoundBuffer *load_sample (IFusionSound *sound, const char *filename);

#endif

